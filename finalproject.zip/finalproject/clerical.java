package finalproject;

public class clerical {
	private String name,rid;
	public clerical()
	{
		
	}
	public clerical(String name,String rid)
	{
		this.name=name;
		this.rid=rid;
	}
	public String getname()
	{
		return this.name;
	}
	public String getrid()
	{
		return this.rid;
	}
	public void setname(String name)
	{
		this.name=name;
	}
	public void setrid(String rid)
	{
		this.rid=rid;
	}
}

